import React, { Component } from 'react'
import { BrowserRouter, Route } from 'react-router-dom'

import NavBar from './components/Navbar'

import Home from './components/Home'
import CreatePosts from './components/CreatePosts'
import EditPosts from './components/EditPosts'
import PostDetails from './components/PostDetails'

export default class App extends Component {
  render() {
    return (

      <BrowserRouter>
        <NavBar />
        <div className="container">
          
          <Route path="/" exact component={Home} ></Route>
          <Route path="/add" component={CreatePosts} ></Route>
          <Route path="/edit/:id" component={EditPosts} ></Route>
          <Route path="/post/:id" component={PostDetails} ></Route>
        </div>
      </BrowserRouter>
    )
  }
}
