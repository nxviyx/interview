import React, { Component } from 'react'
import axios from 'axios'

export default class Home extends Component {

  constructor(props){
    super(props)

    this.state = {
      posts: []
    };
  }

  retrievePosts(){
    axios.get('https://jsonplaceholder.typicode.com/posts')
      .then(res => {
        if(res.data.length > 0){

          this.setState({
            posts:res.data
          })

          console.log(this.state.posts);

        }
      })
  }

  onDeleteExercise(id){
    axios.get('http://localhost:5000/exercises/'+id)
        .then(res => console.log(res.data))
    
    //return all the rows where id is not equals to deleted id
    this.setState({
      posts: this.state.posts.filter(el => el._id !== id)
    })
  }


  //after render all components
  componentDidMount(){
    this.retrievePosts()
  }

  render() {
    return (
      <div className="container">
        <p>All Posts</p>
        
        <button className="btn btn-success">
          <a href="/add" style={{textDecoration:'none',color: 'white'}}>  Create Post </a>
        </button>

        <table className="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">id</th>
              <th scope="col">title</th>
              <th scope="col">body</th>
              <th scope="col">Edit</th>
              <th scope="col">Delete</th>
            </tr>
          </thead>
          <tbody>
          {this.state.posts.map((posts,idx) => (
            <tr key={idx}>
              <th scope="row">{idx + 1 }</th>
              <td><a href={`post/${posts.id}`} style={{textDecoration:'none',color: 'black'}}> {posts.title}</a></td>
              <td>{posts.body}</td>
              <td>{posts.userId}</td>
              <td>
                <a href={`post/${posts.id}`} className="btn btn-warning">edit</a>
              </td>
              <td>
                <a href={`post/${posts.id}`} className="btn btn-danger">delete</a>
              </td>
            </tr>
          ))}
          </tbody>
        </table>

        
      </div>
    )
  }
}
