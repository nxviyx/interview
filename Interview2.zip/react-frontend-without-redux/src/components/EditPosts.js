import React, { Component } from 'react'

export default class EditPosts extends Component {
    render() {
        return (
            <div>
                EditPosts
            </div>
        )
    }
}
