import React, { Component } from 'react'
import axios from 'axios'

export default class PostDetails extends Component {

    constructor(props){
        super(props)
    
        this.state = {
          post: {}
        };
    }

    retrievePostsbyId(id){
        axios.get('https://jsonplaceholder.typicode.com/posts/'+id)
          .then(res => {
            if(res.data.length = 1){
    
              this.setState({
                post:res.data
              })
    
              console.log(this.state.post);
    
            }
          })
      }
    
    componentDidMount(){
        console.log("hello world");
        const id = this.props.match.params.id
        console.log(id)
        this.retrievePostsbyId(id)
    }

    render() {

        const {title, body} = this.state.post;

        return (

            <div>
                
                <p><b>Title: </b>{title}</p>

                <p><b>Description: </b>{body}</p>

            </div>
        )
    }
}
