import React, { Component } from 'react'
import axios from 'axios'

export default class CreatePosts extends Component {

    constructor(props){
        super(props)

        this.onChangeDescription = this.onChangeDescription.bind(this)
        this.onChangeTitle = this.onChangeTitle.bind(this)
        this.onSubmit = this.onSubmit.bind(this)

        this.state = {
          title: "",
          description: ""
        };
    }

    onChangeTitle(e){
        this.setState({
            title: e.target.value
        })
    }

    onChangeDescription(e){
        this.setState({
            description: e.target.value
        })
    }

    onSubmit(e){
        e.preventDefault();
        const exercise = {
            title: this.state.title,
            description: this.state.description,
        }

        console.log(exercise);

        axios.post('http://localhost:5000/exercises/add',exercise)
            .then(res => {console.log(res.data);})

        window.location = "/"

    }

    render() {
        
        return (
            <div className="container">
                <form onSubmit={this.onSubmit}>

                        <label>Title: </label>
                        <input
                            type="text"
                            // required
                            className="form-control"
                            value={this.state.title}
                            onChange={this.onChangeTitle}
                        ></input><br/>

                        <label>Description: </label>
                        <input
                            type="text"
                            // required
                            className="form-control"
                            value={this.state.description}
                            onChange={this.onChangeDescription}
                        ></input><br/>

                        <input
                            type="submit"
                            value="Create Post" 
                            className="btn btn-primary"
                            onChange={this.onSubmit}/>

                    </form>
            </div>
        )
    }
}
