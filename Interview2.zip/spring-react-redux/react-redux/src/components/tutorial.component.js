import React, { Component } from 'react'

export default class tutorial extends Component {
    render() {
        return (
            <div>
                tutorial
            </div>
        )
    }
}
