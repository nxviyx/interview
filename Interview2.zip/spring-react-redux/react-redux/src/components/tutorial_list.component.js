import React, { Component } from 'react'

export default class tutorial_list extends Component {
    render() {
        return (
            <div>
                tutorial list
            </div>
        )
    }
}
