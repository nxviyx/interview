import React, { Component } from 'react'

export default class add_tutorial extends Component {
    render() {
        return (
            <div>
                add tutorials
            </div>
        )
    }
}
