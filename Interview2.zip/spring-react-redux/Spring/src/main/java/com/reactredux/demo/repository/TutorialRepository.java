package com.reactredux.demo.repository;

import com.reactredux.demo.model.Tutorial;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TutorialRepository extends JpaRepository<Tutorial, Long> {

    /*custom methods*/
    List<Tutorial> findByPublished(boolean published);

    Optional<Tutorial> findTutorialById(Long id);

}
