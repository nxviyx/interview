import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/models/employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees: Employee[]


  constructor( private employeeService: EmployeeService,  private router: Router ) { }

  ngOnInit(): void {
    console.log("hellow");
    
    this.getEmployees();
  }

  getEmployees(){
      this.employeeService.getEmployeeList().subscribe(data=>{
        console.log(data);
        
        this.employees = data
      })
  }

  updateEmployee(id: number){
    this.router.navigate(['update-employee',id])
  }

  deleteEmployee(id:number){
    console.log(id);
    
    this.employeeService.deleteEmployee(id).subscribe(data=>{
    //   console.log(data);
      this.getEmployees()
      })
    }

    ViewEmployee(id:number){
      this.router.navigate(['view-employee',id])
    }
}
