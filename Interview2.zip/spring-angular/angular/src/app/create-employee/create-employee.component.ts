import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../models/employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  isAddMode!: boolean;
  id!: number
  submitted = false;


  employee: Employee;

  constructor(
    private employeeService: EmployeeService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.id = this.route.snapshot.params['id'];
    this.isAddMode = !this.id;
    this.employee = new Employee();

    if (!this.isAddMode) {
        this.employeeService.getEmployeeById(this.id ).subscribe(data=>{
        this.employee = data
      })
    }

  }

  onSubmit(){
    if (this.isAddMode) {
      this.createEmployee();
    } else {
      this.updateEmployee();
    }
  }

  createEmployee(){
    this.employeeService.createEmployee(this.employee).subscribe(data=>{
      console.log(data);
      this.goToEmployeeList()
      
    },
      error=> console.log(error)
    )
  }

  updateEmployee(){
    this.employeeService.updateEmployee(this.id,this.employee).subscribe(data=>{
    console.log(data);
    this.goToEmployeeList()
    })
  }

  goToEmployeeList(){
    this.router.navigate(['/employees'])
  } 
}
