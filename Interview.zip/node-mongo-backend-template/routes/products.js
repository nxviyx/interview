const router = require('express').Router();

let Product = require('../models/product.model');

//get all items
router.route('/').get((req, res) => {
    Product.find()
        .then(products => res.json(products))
        .catch(err => res.status(400).json('Error: '+ err))
})

//insert item
router.route('/add').post((req, res) => {
    const title = req.body.title;
    const description = req.body.description;
    const price = Number(req.body.price);
    const date = Date.parse(req.body.date);
  
    const newProduct = new Exercise({
      title,
      description,
      price,
      date,
    });
  
    newProduct.save()
    .then(() => res.json('Product added!'))
    .catch(err => res.status(400).json('Error: ' + err));
  });
  
  //get item by id
  router.route('/:id').get((req, res) => {
    Product.findById(req.params.id)
      .then(product => res.json(product))
      .catch(err => res.status(400).json('Error: ' + err));
  });
  
  //delete item by id
  router.route('/:id').delete((req, res) => {
    Product.findByIdAndDelete(req.params.id)
      .then(() => res.json('Product deleted.'))
      .catch(err => res.status(400).json('Error: ' + err));
  });
  
  //update item by id
  router.route('/update/:id').post((req, res) => {
    Product.findById(req.params.id)
      .then(product => {
        product.title = req.body.title;
        product.description = req.body.description;
        product.price = Number(req.body.price);
        product.date = Date.parse(req.body.date);
  
        product.save()
          .then(() => res.json('Product updated!'))
          .catch(err => res.status(400).json('Error: ' + err));
      })
      .catch(err => res.status(400).json('Error: ' + err));
  });
  
  module.exports = router;