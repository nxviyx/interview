const express = require('express');

const productController = require('../controllers/products');

const router = express.Router();

router.get('/', productController.fetchAll);

router.post('/', productController.postProduct);

router.delete('/:id', productController.deleteProduct);

module.exports = router;