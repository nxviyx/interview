const Post = require('../models/post');

exports.fetchAll = async (req, res, next) => {
    try {
      const [allPosts] = await Post.fetchAll();
      res.status(200).json(allPosts);
    } catch (err) {
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      next(err);
    }
  };

  exports.postProduct = async (req, res, next) => {

    const title = req.body.title;
    const description = req.body.description;
    const price = req.body.price;
  
    try {
      const product = {
        title: title,
        description: description,
        price: price,
      };
      const result = await Product.save(post);
      res.status(201).json({ message: 'Posted!' });
    } catch (err) {
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      next(err);
    }
  };
  
  exports.deleteProduct = async (req, res, next) => {
    try {
      const deleteResponse = await Post.delete(req.params.id);
      res.status(200).json(deleteResponse);
    } catch (err) {
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      next(err);
    }
  };