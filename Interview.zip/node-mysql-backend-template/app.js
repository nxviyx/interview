const express = require('express');

const bodyParser = require('body-parser');

const app = express();

const ports = process.env.PORT || 3000;

app.use(bodyParser.json());

const productRoutes = require('./routes/products');

app.use('/product', productRoutes);

app.listen(ports, () => console.log(`Listening on port ${ports}`));