const db = require('../util/database');

module.exports = class Product {
  constructor(title, description, price) {
    this.title = title;
    this.description = description;
    this.price = price;
  }

  //find product by id
  static find(id) {
    return db.execute('SELECT * FROM products WHERE id = ?', [id]);
  }

  //insert product
  static save(product) {
    return db.execute(
      'INSERT INTO products (title, description, price) VALUES (?, ?, ?)',
      [product.title, product.description, user.product]
    );
  }

  //delete product
  static delete(id) {
    return db.execute('DELETE FROM products WHERE id = ?', [id]);
  }

  //get all products
  static fetchAll() {
    return db.execute('SELECT * FROM products');
  }
  
};