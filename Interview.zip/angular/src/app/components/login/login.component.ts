import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators'; 

import { RegisterService } from 'src/app/services/register.service';
import { AlertService } from 'src/app/services/alert.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit { 

  loginForm: FormGroup;
  submitted = false;
  loading = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private registerService : RegisterService,
    private alertService : AlertService

  ) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password:['',[Validators.required,Validators.minLength(5)]]
    })
   }

   get f() { return this.loginForm.controls; }

  onSubmit() {

    this.submitted = true;

    if (this.loginForm.invalid) { 
      return;
    }

    this.loading = true;

    // console.log('Your form data : ', this.loginForm.value );

    this.registerService.loginUser(this.loginForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data['response']){

            sessionStorage.setItem('current_user', JSON.stringify(data['current_user']));
            sessionStorage.setItem('isLoggedIn', JSON.stringify(data['isLoggedIn']));

            this.alertService.success(data['message'], true);
            this.router.navigate(['/home']);
          }else{
            this.alertService.error(data['message'], true);
          }
        },
        error => {
          this.router.navigate(['/login']);
          this.loading = false;
        });
  }
}
