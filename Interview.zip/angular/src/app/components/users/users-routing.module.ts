import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserLayoutComponent } from './user-layout.component';
import { UserListComponent } from './user-list.component';
import { UserAddEditComponent } from './user-add-edit.component';
// import { PatientProfileComponent } from './patient-profile.component';

const routes: Routes = [
    {
        path: '', component: UserLayoutComponent,
        children: [
            { path: '', component: UserListComponent },
            { path: 'add', component: UserAddEditComponent },
            { path: 'edit/:id', component: UserAddEditComponent },
            // { path: 'profile/:id', component: PatientProfileComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class UsersRoutingModule { }