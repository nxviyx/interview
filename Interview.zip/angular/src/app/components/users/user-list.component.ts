import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { UserService } from 'src/app/services/user.service';
import { AlertService } from 'src/app/services/alert.service';

@Component({ templateUrl: 'user-list.component.html',
styleUrls: ['./user-list.component.css']  })

export class UserListComponent implements OnInit {
    users:any = [];
    searchText
    constructor(private userService: UserService,private alertService : AlertService) {}

    ngOnInit() {
        this.getAllUsers()
    }

    getAllUsers(){
        this.users = [];
        this.userService.getAllUsers().pipe(first()).subscribe(users => {
          console.log(users['data'].length);

          console.log(users['data']);
           
          for (let index = 0; index < users['data'].length; index++) {
            var user = {
              "id": users['data'][index][0],
              "first_name": users['data'][index][1],
              "last_name": users['data'][index][2],
              "address": users['data'][index][3],
              "email": users['data'][index][4],
              "gender": users['data'][index][5],
              "avatar": users['data'][index][6],
              "designation": users['data'][index][7],
            }
            this.users.push(user)
          }
          console.log(this.users);
      },error => {
      //   this.router.navigate(['']);
      });
      }
 
      onDelete(id:string){
        console.log(id);
        this.userService.deleteUserById(id).pipe(first()).subscribe(res => {
          if(res['response']){
            this.alertService.success(res['message'], true);
            this.getAllUsers()
          }else{
            this.alertService.error(res['message'], true);
          }
        })
      }

}