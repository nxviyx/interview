import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { UsersRoutingModule } from './users-routing.module';
import { UserLayoutComponent } from './user-layout.component';
import { UserListComponent } from './user-list.component';
import { UserAddEditComponent } from './user-add-edit.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
// import { PatientProfileComponent } from './patient-profile.component'
@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        UsersRoutingModule,
        Ng2SearchPipeModule,
        FormsModule
    ],
    declarations: [
        UserLayoutComponent,
        UserListComponent,
        UserAddEditComponent,
        // PatientProfileComponent
    ]
})
export class UsersModule { }