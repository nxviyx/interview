import { Component } from '@angular/core';

@Component({ selector: 'app-user-layout',templateUrl: 'user-layout.component.html' })
export class UserLayoutComponent { 

    ngOnInit() {
        console.log('holaaaaa layout');

      }

}  