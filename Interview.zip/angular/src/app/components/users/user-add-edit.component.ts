import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { UserService } from 'src/app/services/user.service';
import { AlertService } from 'src/app/services/alert.service';
import { MustMatch } from 'src/app/helpers/must-match.validator';

@Component({ templateUrl: 'user-add-edit.component.html',
styleUrls: ['./user-add-edit.component.css']  })

export class UserAddEditComponent implements OnInit {
    createUserForm: FormGroup;
    image_url 
    id!: string;
    isAddMode!: boolean;
    submitted = false;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private userService: UserService,
        private alertService: AlertService 
    ) {}

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];
        this.isAddMode = !this.id;
        
        const formOptions: AbstractControlOptions = { validators: MustMatch('password', 'confirm_password') };
        this.createUserForm = this.formBuilder.group({
            first_name:['',Validators.required],
            last_name:['',Validators.required],
            designation:['',Validators.required],
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.minLength(6), this.isAddMode ? Validators.required : Validators.nullValidator]],
            confirm_password: ['', this.isAddMode ? Validators.required : Validators.nullValidator],
            avatar:[null],
            address:['',Validators.required],
            gender:['',Validators.required]
          }, formOptions)

          const passwordValidators = [Validators.minLength(6)];
        if (this.isAddMode) {
            passwordValidators.push(Validators.required);
        }

          if (!this.isAddMode) {
            this.userService.getUserById(this.id)
                .pipe(first())
                .subscribe(x => {
                    this.createUserForm.patchValue({"id": x['data'][0]});
                    this.createUserForm.patchValue({"first_name": x['data'][1]});
                    this.createUserForm.patchValue({"last_name": x['data'][2]});
                    this.createUserForm.patchValue({"address": x['data'][3]});
                    this.createUserForm.patchValue({"email": x['data'][4]});
                    this.createUserForm.patchValue({"gender": x['data'][5]});
                    this.createUserForm.patchValue({"avatar": x['data'][6]});
                    this.createUserForm.patchValue({"designation": x['data'][7]});

                    this.image_url = x['data'][6]

                    console.log(this.createUserForm);
                    
                });
        }

    }
    get f() { return this.createUserForm.controls; }

    onSubmit() {
      this.submitted = true;

      // reset alerts on submit
      // this.alertService.clear();

      // stop here if form is invalid
      if (this.createUserForm.invalid) {
          return;
      }

      // this.loading = true;
      if (this.isAddMode) {
          this.createUser();
      } else {
          this.updateUser();  
      }
  }

  private createUser() {
    this.userService.createUser(this.createUserForm.value)
        .pipe(first())
        .subscribe(
            data => {
              if(data['response']){
                this.alertService.success(data['message'], true);
                this.router.navigate(['../'], { relativeTo: this.route });
              }else{
                this.alertService.error(data['message'], true);
              }
            },
            error => {
              this.router.navigate(['']);
            });    
        }
        private updateUser() {
            this.userService.updateUser(this.id, this.createUserForm.value)
                .pipe(first())
                .subscribe(() => {
                    this.alertService.success('User updated',  true );
                    this.router.navigate(['../../'], { relativeTo: this.route });
                })
        }


    showPreview(event) {
        const file = (event.target as HTMLInputElement).files[0];
      
        // File Preview
        const reader = new FileReader();
        reader.onload = () => {
          this.image_url = reader.result as string;
      
          this.createUserForm.patchValue({
            avatar: reader.result as string
          });
          this.createUserForm.get('avatar').updateValueAndValidity()
      
        }
        reader.readAsDataURL(file)
      }

}