import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { PatientService } from 'src/app/services/patient.service';
import { AlertService } from 'src/app/services/alert.service';

@Component({ selector: 'app-add-edit',templateUrl: 'add-edit.component.html',
styleUrls: ['./add-edit.component.css']  })

export class AddEditComponent implements OnInit {
    createPatientForm: FormGroup;
    image_url 
    id!: string;
    isAddMode!: boolean;
    submitted = false;


    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private patientService: PatientService,
        private alertService: AlertService
    ) {}

    ngOnInit() {

        this.id = this.route.snapshot.params['id'];
        this.isAddMode = !this.id;
        
        this.createPatientForm = this.formBuilder.group({
            first_name:['',Validators.required],
            last_name:['',Validators.required],
            email: ['', [Validators.required, Validators.email]],
            address:['',Validators.required],
            age:['',Validators.required],
            dob:['',Validators.required],
            avatar:[null],
          })
          if (!this.isAddMode) {
            this.patientService.getPatientById(this.id)
                .pipe(first())
                .subscribe(x => {
                    this.createPatientForm.patchValue({"id": x['data'][0]});
                    this.createPatientForm.patchValue({"first_name": x['data'][1]});
                    this.createPatientForm.patchValue({"last_name": x['data'][2]});
                    this.createPatientForm.patchValue({"address": x['data'][3]});
                    this.createPatientForm.patchValue({"email": x['data'][4]});
                    this.createPatientForm.patchValue({"age": x['data'][5]});
                    this.createPatientForm.patchValue({"dob": new Date(x['data'][6]).toISOString().split("T")[0]}); 
                    this.createPatientForm.patchValue({"avatar": x['data'][7]});

                    this.image_url = x['data'][7]


                });
        }
    }
    get f() { return this.createPatientForm.controls; }
    onSubmit() {
        this.submitted = true; 

        // reset alerts on submit
        // this.alertService.clear();

        // stop here if form is invalid
        if (this.createPatientForm.invalid) {
            return;
        }

        // this.loading = true; 
        if (this.isAddMode) {
            this.createUser();
        } else {
            this.updateUser();
        }
    }

    private createUser() {
        this.patientService.createPatient(this.createPatientForm.value)
            .pipe(first())
            .subscribe(
                data => {
                  if(data['response']){
                    this.alertService.success(data['message'], true);
                    this.router.navigate(['../'], { relativeTo: this.route });
                  }else{
                    this.alertService.error(data['message'], true);
                  }
                },
                error => {
                  this.router.navigate(['']);
                });  
            // .subscribe(() => {
            //     this.alertService.success('New Patient added Successfully', true);
            //     this.router.navigate(['../'], { relativeTo: this.route });
            // })
    }
    private updateUser() {
        this.patientService.updatePatient(this.id, this.createPatientForm.value)
            .pipe(first())
            .subscribe(() => {
                this.alertService.success('Patient has successfully updated',  true );
                this.router.navigate(['../../'], { relativeTo: this.route });
            })
    }
    showPreview(event) {
        const file = (event.target as HTMLInputElement).files[0];
      
        // File Preview
        const reader = new FileReader();
        reader.onload = () => {
          this.image_url = reader.result as string;
      
          this.createPatientForm.patchValue({
            avatar: reader.result as string
          });
          this.createPatientForm.get('avatar').updateValueAndValidity()
      
        }
        reader.readAsDataURL(file)
      }

}