import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
// AfterViewInit
import { PatientService } from 'src/app/services/patient.service';
import { AlertService } from 'src/app/services/alert.service';
import * as Highcharts from "highcharts";

@Component({ 
    templateUrl: 'view-file.component.html',
    styleUrls: ['./view-file.component.css','./spinner.css']})

export class ViewFileComponent implements OnInit {
    id:string = ""
    filename:string = ""
    loading = false;

    @ViewChild("charts") public chartEl: ElementRef;
    chartss = [];

    constructor( 
        private patientService:PatientService,
        private route: ActivatedRoute,
         ){}

      axesOptions = {
          tickInterval: 0.5,
          minorTicks: true,
          minorTickInterval: 0.1,
          gridLineWidth: 1,
          gridLineColor: 'red'
        };
    
    options = {
        chart: {
          zoomType: "x",
        //   width: 600,
        //     events: {
        //     render: function() {
        //         // let xValue = (this.xAxis[0].toPixels(Date.UTC(2014, 10, 20)));
        //         this.renderer.image('https://cdn.iconscout.com/icon/free/png-256/small-diamond-geometric-orange-38007.png', 160, 160, 30, 30)
        //         .add();
        //     }
        // }
        },
        subtitle: {
          text:
            document.ontouchstart === undefined
              ? "Drag in the plot area to zoom in"
              : "Pinch the chart to zoom in"
        },
        // xAxis: {
        //   type: "time",
        // },
        // yAxis: {
        //   title: {
        //     text: "mv/s"
        //   }
      // },
        xAxis: this.axesOptions,
        yAxis: this.axesOptions,
        
        legend: {
          enabled: false
        },
        plotOptions: {
          area: {
            fillColor: {
              linearGradient: {
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 1
              },
              stops: [
                [0, Highcharts.getOptions().colors[0]],
                [
                  1,
                  Highcharts.color(Highcharts.getOptions().colors[0])
                    .setOpacity(0)
                    .get("rgba")
                ]
              ]
            },
            marker: {
              radius: 2
            },
            lineWidth: 1,
            states: {
              hover: {
                lineWidth: 1
              }
            },
            threshold: null
          }
        },
        // series: [
        //   {
        //     name: "without filter",
        //     data: tmp,
        //     color: 'black',
        //   },
        //   {
        //     name: "With low pass filter",
        //     data: filterd_tmp,
        //   },
        // ]
    };

    ngOnInit() {
        this.loading = true;
        setTimeout(() => {
            this.route.paramMap.subscribe(params => {
                console.log('accessed',params.get('ecgid'));
                this.id = params.get('id')
                this.patientService.view_file(params.get('ecgid'))
                .pipe(first())
                .subscribe(data => {
                    console.log(data['data']); 
                    console.log(data['data']['signals'].length);
                    this.filename = data['data']['filename']
                    
                    for (let index = 0; index < data['data']['signals'].length; index++) {
                        var title = "Lead " + this.lead_name_finder(data['data']['signals'][index]['index'])
                        var tmp = data['data']['signals'][index]['series']
                        var filterd_tmp = data['data']['signals'][index]['filter_series']

                        this.ecg_lead_chart_builder(title,tmp,filterd_tmp)
                        this.loading = false;
                    }
                })
            })
        },50)
    }

    ecg_lead_chart_builder(text:any,tmp,filtered_tmp, options?: Object){
        let container = this.chartEl.nativeElement
        let opts = !!options ? options : this.options;
        let e = document.createElement("div");
        container.appendChild(e);
        opts['chart'] = {
            'zoomType': "x",
            'renderTo': e,
            events: {
              render: function() {
        
                var axes = this.axes,
                  showMinorTicks = true;
        
                // find if minor ticks are present on both axes
                axes.forEach(function(a) {
                  console.log(a.minorTicks);
        
                  if (Object.keys(a.minorTicks).length === 0) {
                    showMinorTicks = false;
                  }
                });
        
                // hide/show ticks
                axes.forEach(function(a) {
                  for (var key in a.minorTicks) {
                    var mt = a.minorTicks[key].gridLine;
                    showMinorTicks ? mt.show() : mt.hide();
                  }
                });
              }
            }
        }
        opts['title'] = {
            'text': `<p style="color: #435e83 "><b>`+text+`</b></p>`
        },
        opts['series'] = [
          {
            name: "without filter",
            data: tmp,
            color: `#21cdc0`,
          },
          {
            name: "With low pass filter",
            data: filtered_tmp,
            color: `#435e83`,
          }
            
        ]
        this.chartss.push(new Highcharts.Chart(opts));
    }

    lead_name_finder(lead_index){
        switch(lead_index) {
            case 0: return "I";
            case 1: return "II";
            case 2: return "III";
            case 3: return "AVR";
            case 4: return "AVF";
            case 5: return "AVL";
            case 6: return "V1";
            case 7: return "V2";
            case 8: return "V3";
            case 9: return "V4";
            case 10: return "V5";
            case 11: return "V6";
            default: return "-";
          }
    }
}