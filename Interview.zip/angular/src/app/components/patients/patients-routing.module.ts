import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutComponent } from './layout.component';
import { ListComponent } from './list.component';
import { AddEditComponent } from './add-edit.component';
import { PatientProfileComponent } from './patient-profile.component';
import { ViewFileComponent } from './view-file.component'
import { ResultsComponent } from './results.component'

const routes: Routes = [
    {
        path: '', component: LayoutComponent,
        children: [
            { path: '', component: ListComponent },
            { path: 'add', component: AddEditComponent },
            { path: 'edit/:id', component: AddEditComponent },
            { path: 'profile/:id', component: PatientProfileComponent },
            { path: 'profile/:id/:ecgid', component: ResultsComponent },
            { path: 'profile/file/:id/:ecgid', component: ViewFileComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)], 
    exports: [RouterModule]
})
export class PatientsRoutingModule { }