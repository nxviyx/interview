import { Component, ElementRef, OnInit, ViewChild,Renderer2 } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
// AfterViewInit
import { PatientService } from 'src/app/services/patient.service';
import { AlertService } from 'src/app/services/alert.service';
import * as Highcharts from "highcharts";


@Component({ 
  templateUrl: 'results.component.html',
  styleUrls: ['./results.component.css','./spinner.css']})

export class ResultsComponent implements OnInit {
    @ViewChild("charts") public chartEl: ElementRef;
    @ViewChild("charts1") public chartEl1: ElementRef;
    id:string = ""
    selectors:any = []
    options_list = []
    images = []
    // options: any = {}
    // charts:any =[]
    timeToShow:boolean = false
    loading = false;

    chartss = [];
    chartss1 = [];
    predictions = []

    axesOptions = {
      tickInterval: 0.5,
      minorTicks: true,
      minorTickInterval: 0.1,
      gridLineWidth: 1,
      gridLineColor: 'red'
    };

    options = {
        chart: {
          zoomType: "x",
        //   width: 600,
        //     events: {
        //     render: function() {
        //         // let xValue = (this.xAxis[0].toPixels(Date.UTC(2014, 10, 20)));
        //         this.renderer.image('https://cdn.iconscout.com/icon/free/png-256/small-diamond-geometric-orange-38007.png', 160, 160, 30, 30)
        //         .add();
        //     }
        // }
        },
        subtitle: {
          text:
            document.ontouchstart === undefined
              ? "Drag in the plot area to zoom in"
              : "Pinch the chart to zoom in"
        },
        // xAxis: {
        //   type: "time",
        // },
        // yAxis: {
        //   title: {
        //     text: "mv/s"
        //   }
      // },
        xAxis: this.axesOptions,
        yAxis: this.axesOptions,
        
        legend: {
          enabled: false
        },
        plotOptions: {
          area: {
            fillColor: {
              linearGradient: {
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 1
              },
              stops: [
                [0, Highcharts.getOptions().colors[0]],
                [
                  1,
                  Highcharts.color(Highcharts.getOptions().colors[0])
                    .setOpacity(0)
                    .get("rgba")
                ]
              ]
            },
            marker: {
              radius: 2
            },
            lineWidth: 1,
            states: {
              hover: {
                lineWidth: 1
              }
            },
            threshold: null
          }
        },
        // series: [
        //   {
        //     name: "without filter",
        //     data: tmp,
        //     color: 'black',
        //   },
        //   {
        //     name: "With low pass filter",
        //     data: filterd_tmp,
        //   },
        // ]
    };

    public element: string;

    constructor( 
        private patientService:PatientService,
        private route: ActivatedRoute,
        private renderer: Renderer2
         ) {

         }

    ngOnInit() {

        this.loading = true;
        console.log("afterinit");

        setTimeout(() => {
          this.route.paramMap.subscribe(params => {
              console.log('accessed',params.get('ecgid'));
              this.id = params.get('id')
              this.patientService.getPredictionReportById(params.get('ecgid'))
              .pipe(first())
              .subscribe(data => {
                  console.log(data['data']); 
                  console.log(data['data'].length);
                  for (let index = 0; index < data['data'].length; index++) {

                      var tmp = data['data'][index]['raw_heartbeat_signal']
                      var filterd_tmp = data['data'][index]['filtered_heartbeat_signal']
                      var title =  data['data'][index]['filename'] +" | Lead " + this.lead_name_finder(data['data'][index]['lead_index']) + "| Heartbeat " + data['data'][index]['beat_index']
                      this.ecg_lead_chart_builder(title,tmp,filterd_tmp)

                      var model_prediction = data['data'][index]['model_prediction']
                      this.addElement(model_prediction)
                      this.loading = false;
                      this.predictions.push(model_prediction[0])

                  }

                  console.log(this.predictions);
                  

              })
          })
      },50)
        
    }

addElement(model_prediction) {

    var tableString = `
      <table class="table table-striped">
        <thead>
          <tr>
            <th style="color: #435e83 ">Beat index</th>
            <th style="color: #435e83 ">Image type</th>
            <th style="color: #435e83 ">Model id</th>
            <th style="color: #435e83 ">Model name</th>
            <th style="color: #435e83 ">Method</th>
            <th style="color: #435e83 ">Prediction</th>
            <th style="color: #435e83 ">Diseased Area</th>
          </tr>
        </thead>
      <tbody>`,
      
    div = document.createElement('div');

    for (let row = 0; row < model_prediction.length; row ++) {

        tableString += "<tr>";

        tableString += `<td style="color: grey">` + model_prediction[row]['beat_index'] + "</td>";
        tableString += `<td style="color: grey">` + model_prediction[row]['image_type'] + "</td>";
        tableString += `<td style="color: grey">` + model_prediction[row]['model_id'] + "</td>";
        tableString += `<td style="color: grey">` + model_prediction[row]['model_name'] + "</td>";
        tableString += `<td style="color: grey">` + model_prediction[row]['trained_method'] + "</td>";
        tableString += `<td style="color: grey">` + model_prediction[row]['prediction'] + "</td>";
        tableString += `<td style="color: grey">` + model_prediction[row]['diseased_area'] + "</td>";

        tableString += "</tr>";
    }

    tableString += "</tbody></table><br><hr>";
    div.innerHTML = tableString;

      this.renderer.appendChild(this.chartEl.nativeElement, div)
    }

    ecg_lead_chart_builder(text:any,tmp,filtered_tmp, options?: Object){
        let container = this.chartEl.nativeElement
        let opts = !!options ? options : this.options;
        let e = document.createElement("div");
        container.appendChild(e);
        opts['chart'] = {
            'zoomType': "x",
            'renderTo': e,
            events: {
              render: function() {
        
                var axes = this.axes,
                  showMinorTicks = true;
        
                // find if minor ticks are present on both axes
                axes.forEach(function(a) {
                  // console.log(a.minorTicks);
        
                  if (Object.keys(a.minorTicks).length === 0) {
                    showMinorTicks = false;
                  }
                });
        
                // hide/show ticks
                axes.forEach(function(a) {
                  for (var key in a.minorTicks) {
                    var mt = a.minorTicks[key].gridLine;
                    showMinorTicks ? mt.show() : mt.hide();
                  }
                });
              }
            }
        }
        opts['title'] = {
          'useHTML': true,
            'text': `<p style="color: #435e83 "><b>`+text+`</b></p>`
        },
        opts['series'] = [
              {
                name: "without filter",
                data: tmp,
                color: `#21cdc0`,
              },
              {
                name: "With low pass filter",
                data: filtered_tmp,
                color: `#435e83`,
              },
            
        ]
        this.chartss.push(new Highcharts.Chart(opts));
    }

    lead_name_finder(lead_index){
      switch(lead_index) {
          case 0: return "I";
          case 1: return "II";
          case 2: return "III";
          case 3: return "AVR";
          case 4: return "AVL";
          case 5: return "AVF";
          case 6: return "V1";
          case 7: return "V2";
          case 8: return "V3";
          case 9: return "V4";
          case 10: return "V5";
          case 11: return "V6";
          default: return "-";
        }
      }



}