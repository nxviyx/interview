import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { PatientService } from 'src/app/services/patient.service';
import { AlertService } from 'src/app/services/alert.service';

@Component({ templateUrl: 'list.component.html',
styleUrls: ['./list.component.css'] })

export class ListComponent implements OnInit {
    patients:any = [];
    searchText 
    // loading = false

    constructor(private patientService: PatientService,private alertService : AlertService) {
      this.getAllPatients()
    }

    ngOnInit() {
        // this.getAllPatients()
    }

    getAllPatients(){
      // this.loading = true
      this.patients = [];
      this.patientService.getAllPatients().pipe(first()).subscribe(patients => {
        console.log(patients['data'].length); 
         
        for (let index = 0; index < patients['data'].length; index++) {
          var patient = {
            "id": patients['data'][index][0],
            "first_name": patients['data'][index][1],
            "last_name": patients['data'][index][2],
            "address": patients['data'][index][3],
            "email": patients['data'][index][4],
            "age": patients['data'][index][5],
            "dob": new Date(patients['data'][index][6]).toISOString().split("T")[0], 
            "avatar": patients['data'][index][7],
          }
          this.patients.push(patient)
        }
        // this.loading = false
        console.log(this.patients);
    },error => {
    //   this.router.navigate(['']);
    });
    }

    onDelete(id:string){
        console.log(id);
        this.patientService.deletePatientById(id).pipe(first()).subscribe(res => {
          if(res['response']){
            this.alertService.success(res['message'], true);
            this.getAllPatients()
          }else{
            this.alertService.error(res['message'], true);
          }
        })
      }

}