import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PatientsRoutingModule } from './patients-routing.module';
import { LayoutComponent } from './layout.component';
import { ListComponent } from './list.component';
import { AddEditComponent } from './add-edit.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { PatientProfileComponent } from './patient-profile.component';
import { ResultsComponent } from './results.component'
import { ViewFileComponent } from './view-file.component'

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        PatientsRoutingModule,
        Ng2SearchPipeModule,
        FormsModule
    ],
    declarations: [
        LayoutComponent,
        ListComponent,
        AddEditComponent,
        PatientProfileComponent,
        ResultsComponent,
        ViewFileComponent
    ]
})
export class PatientsModule { }