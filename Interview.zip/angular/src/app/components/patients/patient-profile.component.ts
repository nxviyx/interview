import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PatientService } from 'src/app/services/patient.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators'; 
import { AlertService } from 'src/app/services/alert.service';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import * as Highcharts from "highcharts";


declare var require: any;
const More = require("highcharts/highcharts-more");
More(Highcharts);

const Exporting = require("highcharts/modules/exporting");
Exporting(Highcharts);

const ExportData = require("highcharts/modules/export-data");
ExportData(Highcharts);

const Accessibility = require("highcharts/modules/accessibility");
Accessibility(Highcharts);

@Component({
  selector: 'app-patient-profile',
  templateUrl: 'patient-profile.component.html',
  styleUrls: ['./patient-profile.component.css']
})

// @Component({ templateUrl: 'add-edit.component.html' })

export class PatientProfileComponent implements OnInit {
  loading = false;
  fileUploadForm : FormGroup
  selectedFile: File;
  data:any
  file : File;
  progress: number = 0;
  searchText
  @ViewChild('myInput',{static: true}) myInputVariable: ElementRef;

  uploadedEcgs = []
  id = "" 
  first_name = ""
  last_name = ""
  address = ""
  email = ""
  age = ""
  dob = ""
  avatar = ""
  patientId = ""

  constructor(private route: ActivatedRoute,
    private router: Router,
    private patientService : PatientService,
    private alertService : AlertService,
    private formBuilder: FormBuilder,
    ) { }

  ngOnInit(): void {

      this.fileUploadForm = this.formBuilder.group({
        filename: ['',Validators.required],
        file_url: ['',Validators.required],
        patientId: ['',Validators.required],
      })

      this.route.paramMap.subscribe(params => {
      console.log('accessed',params.get('id'));
      this.patientId = params.get('id')

      this.fileUploadForm.patchValue({
        patientId : params.get('id')
      });

      this.getPatientProfileDetails(params.get('id'))
      this.getAllEcgByPatientId(params.get('id'))
    })

    // this.get_graph()


    
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      this.file = event.target.files[0];
    }
  }

  getAllEcgByPatientId(id){

    this.uploadedEcgs = []
    
    this.patientService.get_all_ecg_by_patient_id(id)
      .pipe(first())
      .subscribe(data => {

          if(data['response']){
            for (let index = 0; index < data['data'].length; index++) {
              var x = {
                'ecg_id' : data['data'][index][0],
                'filename' : data['data'][index][1],
                'patient_id': id
              }
              this.uploadedEcgs.push(x)
            }
          }else{

          }

          console.log(this.uploadedEcgs)
          
      })
  }

  uploadFile(){
    this.patientService.uploadFile(this.file,this.id)
    .subscribe((event: HttpEvent<any>) => {
        this.resetFile();
        
        switch(event.type){
            case HttpEventType.UploadProgress:
              this.progress = Math.round(event.loaded / event.total * 100);
              break;
            
            case HttpEventType.ResponseHeader:
              console.log(HttpEventType.ResponseHeader);
              
              if(event.status == 200){
                this.alertService.success("File was uploaded successfully");
                console.log(event);
                this.getAllEcgByPatientId(this.id)
              }
              if(event.status == 500){
                this.alertService.error("Error while uploading file"); //todo issue filw already uploaded status noy showed
              }
        }
    });
  }
  options: any = {}
  selectors = []


  fileIsUploaded()
  {
    let result = false;
    if(this.file && this.file != null )
    {
      result = true;
    }
    return result;
  }

  resetFile()
  {
    this.myInputVariable.nativeElement.value = "";
    this.file = null;
    this.progress = 0;
  }
  
  getPatientProfileDetails(id){

    console.log('patientid: ',id);
    this.patientService.getPatientById(id).pipe(first()).subscribe(data => {
      console.log(data);

      this.id = data['data'][0]
      this.first_name = data['data'][1]
      this.last_name = data['data'][2]
      this.address = data['data'][3]
      this.email = data['data'][4]
      this.age = data['data'][5]
      this.dob = new Date(data['data'][6]).toISOString().split("T")[0],
      this.avatar = data['data'][7]
      
    },error => {
      this.router.navigate(['']);
    });
}


onFormSubmit(){
  console.log(this.fileUploadForm.value);
  this.loading = true;
  this.patientService.fileUpload(this.fileUploadForm.value)
    .pipe(first())
    .subscribe(data =>{
      if(data['response']){
        this.getAllEcgByPatientId(this.id)
        this.loading = false;
        this.myInputVariable.nativeElement.value = ""
        this.fileUploadForm.reset()

        this.fileUploadForm.patchValue({
          patientId : this.patientId
        });
        this.alertService.success(data['message'], true);
      }else{
        this.loading = false;
        this.alertService.error(data['message'], true);
        
      }

    })
  }

onFileSelected(event){
  const file = (event.target as HTMLInputElement).files[0];
  const reader = new FileReader();
  reader.onload = () => {
    console.log(file.name);
    console.log(reader.result as string);

    this.fileUploadForm.patchValue({
      filename: file.name,
      file_url : reader.result as string
    });

  }
  reader.readAsDataURL(file)
}

}
