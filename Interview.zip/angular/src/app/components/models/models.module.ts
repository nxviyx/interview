import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ModelsRoutingModule } from './models-routing.module';
import { ModelLayoutComponent } from './model-layout.component';
import { ModelListComponent } from './model-list.component';
import { ModelAddEditComponent } from './model-add-edit.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ViewModelProfileComponent } from './view-model-profile.component'

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        ModelsRoutingModule,
        Ng2SearchPipeModule,
        FormsModule
    ],
    declarations: [
        ModelLayoutComponent,
        ModelListComponent,
        ModelAddEditComponent,
        ViewModelProfileComponent
    ]
})
export class ModelsModule { }