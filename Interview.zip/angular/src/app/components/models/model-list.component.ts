import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { ModelService } from 'src/app/services/model.service';
import { AlertService } from 'src/app/services/alert.service';

@Component({ templateUrl: 'model-list.component.html',
styleUrls: ['./model-list.component.css'] })

export class ModelListComponent implements OnInit {
    models:any = [];
    searchText
    constructor(private modelService: ModelService,private alertService : AlertService) {}

    ngOnInit() { 
        this.getAllModels()
    }

    getAllModels(){
        this.models = [];
        this.modelService.getAllModels().pipe(first()).subscribe(models => {
          console.log(models['data'].length);

          console.log(models['data']);
           
          for (let index = 0; index < models['data'].length; index++) {
            var user = {
              "id": models['data'][index][0],
              "model_name": models['data'][index][1],
              "trained_method": models['data'][index][2],
              "lead_index": this.lead_name_finder(models['data'][index][3]),
              "image_type": models['data'][index][4],
              "sample_count": models['data'][index][5],
              "status": this.status_finder(models['data'][index][6]),
              "saved_path": models['data'][index][7],
              "filename":models['data'][index][8],
              "accuracy":models['data'][index][9]
            }
            this.models.push(user)
          }
          console.log(this.models);
      },error => {
        // this.router.navigate(['']);
      });
      }

      lead_name_finder(lead_index){
        switch(lead_index) {
            case 0: return "I";
            case 1: return "II";
            case 2: return "III";
            case 3: return "AVR";
            case 4: return "AVF";
            case 5: return "AVL";
            case 6: return "V1";
            case 7: return "V2";
            case 8: return "V3";
            case 9: return "V4";
            case 10: return "V5";
            case 11: return "V6";
            default: return "-";
          }
        }
        status_finder(status){
            switch(status) {
                case 0: return {'status':"In Active",'enabled':false};
                case 1: return {'status':"Active",'enabled':true};
            }
        }
      

 
      onDelete(id:string,filename:string){
        console.log(id);
        this.modelService.deleteModelById(id,filename).pipe(first()).subscribe(res => {
          if(res['response']){
            this.alertService.success(res['message'], true);
            this.getAllModels()
          }else{
            this.alertService.error(res['message'], true);
          }
        })
      }

}