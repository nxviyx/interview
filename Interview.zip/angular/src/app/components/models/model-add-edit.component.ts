import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { ModelService } from 'src/app/services/model.service';
import { AlertService } from 'src/app/services/alert.service';
import { MustMatch } from 'src/app/helpers/must-match.validator';


@Component({ templateUrl: 'model-add-edit.component.html',
styleUrls: ['./model-add-edit.component.css']  })

export class ModelAddEditComponent implements OnInit {
    // @ViewChild('myInput',{static: true}) myInputVariable: ElementRef;
    createModelForm: FormGroup;
    model_performance
    roc_auc
    id!: string;
    isAddMode!: boolean;
    submitted = false;

    progress: number = 0;
    // file : File;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private modelService: ModelService,
        private alertService: AlertService 
    ) {}

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];
        this.isAddMode = !this.id;

        this.createModelForm = this.formBuilder.group({
            model_name:['',Validators.required],
            trained_method:['',Validators.required],
            lead_index: ['', Validators.required],
            sample_count:['',Validators.required],
            image_type:['',Validators.required],
            status:['',Validators.required],
            model_performance_avatar:[null],
            roc_auc_avatar:[null],
            accuracy:['',Validators.required],
            file:[null,[this.isAddMode ? Validators.required : Validators.nullValidator]],
            filename:['',[this.isAddMode ? Validators.required : Validators.nullValidator]]
          })

          const file = [Validators.required];
          const filename = [Validators.required];
          if (this.isAddMode) {
            file.push(Validators.required);
            filename.push(Validators.required);
          }

          if (!this.isAddMode) {
            this.modelService.getModelById(this.id)
                .pipe(first())
                .subscribe(x => {
                  console.log(x);
                  
                  this.createModelForm.patchValue({"id": x['data'][0]});
                  this.createModelForm.patchValue({"model_name": x['data'][1]});
                  this.createModelForm.patchValue({"trained_method": x['data'][2]});
                  this.createModelForm.patchValue({"lead_index": x['data'][3]});
                  this.createModelForm.patchValue({"image_type": x['data'][4]});
                  this.createModelForm.patchValue({"sample_count": x['data'][5]});
                  this.createModelForm.patchValue({"model_performance_avatar": x['data'][6]});
                  this.createModelForm.patchValue({"roc_auc_avatar": x['data'][7]});
                  this.createModelForm.patchValue({"status": x['data'][8]});
                  this.createModelForm.patchValue({"accuracy": x['data'][11]});

                  this.model_performance = x['data'][6]
                  this.roc_auc = x['data'][7]


                })
          } 
    }
    get f() { return this.createModelForm.controls; }

    onSubmit() {
        this.submitted = true; 
        if (this.createModelForm.invalid) {
            return;
        }
        if (this.isAddMode) {
            this.createModel();
        } else {
            this.updateModel();
        }
    }

    // fileIsUploaded()
    // {
    //   let result = false;
    //   if(this.file && this.file != null )
    //   {
    //     result = true;
    //   }
    //   return result;
    // }

    private createModel() {
        console.log(this.createModelForm.value);
        this.modelService.createModel(this.createModelForm.value)
        .pipe(first())
        .subscribe(
            data => {
              if(data['response']){
                this.router.navigate(['../'], { relativeTo: this.route });
                this.alertService.success('Model Successfully saved');
              }else{
                this.alertService.error('Model already in the database');
              }
            
        })
    }

    private updateModel(){

      console.log("sdsdsdsdsdsdssssss",this.createModelForm.value)

      this.modelService.updateModel(this.id, this.createModelForm.value)
            .pipe(first())
            .subscribe(() => {
                this.alertService.success('Model updated',  true );
                this.router.navigate(['../../'], { relativeTo: this.route });
            })
    }

    showPreviewModelPerformance(event) {
        const file = (event.target as HTMLInputElement).files[0];
      
        // File Preview
        const reader = new FileReader();
        reader.onload = () => {
          this.model_performance = reader.result as string;
      
          this.createModelForm.patchValue({
            model_performance_avatar: reader.result as string
          });
          this.createModelForm.get('model_performance_avatar').updateValueAndValidity()
      
        }
        reader.readAsDataURL(file)
      }

    showPreviewRocAuc(event) {
        const file = (event.target as HTMLInputElement).files[0];
      
        // File Preview
        const reader = new FileReader();
        reader.onload = () => {
          this.roc_auc = reader.result as string;
      
          this.createModelForm.patchValue({
            roc_auc_avatar: reader.result as string
          });
          this.createModelForm.get('roc_auc_avatar').updateValueAndValidity() 
      
        }
        reader.readAsDataURL(file)
      }
      onFileChange(event) {

        let reader = new FileReader();
        if(event.target.files && event.target.files.length) {
            const [file] = event.target.files;

            reader.readAsDataURL(file);
            reader.onload = () => {
                this.createModelForm.patchValue({
                    file: reader.result,
                    filename: file.name
                })
                // this.cd.markForCheck();
            }
        }
      }

      




} 