import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModelService } from 'src/app/services/model.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators'; 
import { AlertService } from 'src/app/services/alert.service';
import { HttpEvent, HttpEventType } from '@angular/common/http';

@Component({
    selector: 'app-patient-profile',
    templateUrl: 'view-model-profile.component.html',
    styleUrls: ['./view-model-profile.component.css']
  })

export class ViewModelProfileComponent implements OnInit {
    id = ''
    trained_method = ''
    model_name = ''
    lead_index = ''
    image_type = ''
    sample_count = ''
    model_performance = ''
    roc_auc = ''
    status = ''
    accuracy = ''
    constructor(private route: ActivatedRoute,
        private router: Router,
        private modelService : ModelService,
        private alertService : AlertService,
        ) { }
    
      ngOnInit(): void {
          this.route.paramMap.subscribe(params => {
          console.log('accessed',params.get('id'));
            this.getModelProfileDetails(params.get('id'))
        })
    }

    getModelProfileDetails(id){

        console.log('patientid: ',id);
        this.modelService.getModelById(id).pipe(first()).subscribe(data => {
          console.log(data);
    
          this.id = data['data'][0]
          this.model_name = data['data'][1]
          this.trained_method = data['data'][2]
          this.lead_index = this.lead_name_finder(data['data'][3])
          this.image_type = data['data'][4]
          this.sample_count = data['data'][5]
          this.model_performance = data['data'][6]
          this.roc_auc = data['data'][7],
          this.status = this.status_finder(data['data'][8]),
          this.accuracy = data['data'][11]
      
        },error => {
          this.router.navigate(['']);
        });
    }

    lead_name_finder(lead_index){
        switch(lead_index) {
            case 0: return "I";
            case 1: return "II";
            case 2: return "III";
            case 3: return "AVR";
            case 4: return "AVF";
            case 5: return "AVL";
            case 6: return "V1";
            case 7: return "V2";
            case 8: return "V3";
            case 9: return "V4";
            case 10: return "V5";
            case 11: return "V6";
            default: return "-";
          }
        }
        status_finder(status){
            switch(status) {
                case 0: return "In Active";
                case 1: return "Active";
            }
        }

}