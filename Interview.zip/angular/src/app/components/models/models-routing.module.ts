import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModelLayoutComponent } from './model-layout.component';
import { ModelListComponent } from './model-list.component';
import { ModelAddEditComponent } from './model-add-edit.component';
import { ViewModelProfileComponent } from './view-model-profile.component'

const routes: Routes = [
    {
        path: '', component: ModelLayoutComponent,
        children: [
            { path: '', component: ModelListComponent },
            { path: 'add', component: ModelAddEditComponent },
            { path: 'edit/:id', component: ModelAddEditComponent },
            { path: 'profile/:id', component: ViewModelProfileComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ModelsRoutingModule { }