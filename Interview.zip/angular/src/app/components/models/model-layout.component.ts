import { Component } from '@angular/core';

@Component({ selector: 'app-model-layout',templateUrl: 'model-layout.component.html' })
export class ModelLayoutComponent { 

    ngOnInit() {
        console.log('holaaaaa model layout');

      }

}  