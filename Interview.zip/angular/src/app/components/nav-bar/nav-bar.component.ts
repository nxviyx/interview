import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators'; 
import { RegisterService } from 'src/app/services/register.service';
import { AlertService } from 'src/app/services/alert.service';


@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {
  userObject
  welcome_msg = ""
  first_name : string = ""
  last_name : string = ""
  designation: string = ""
  avatar :any
  hide = false

  constructor(
    private router: Router,
    private registerService : RegisterService,
    private alertService : AlertService,
  ) {

    this.userObject = JSON.parse(sessionStorage.getItem("current_user"))
    console.log(this.userObject );
    
      if (this.userObject != null ){
        this.hide = false
        this.welcome_msg = "Welcome, "
        this.first_name = this.userObject['first_name']
        this.last_name = this.userObject['last_name']
        this.designation = this.userObject['designation']
        this.avatar = this.userObject['avatar']
      }else{
        console.log('user is not logged in');
        this.hide = true
      }
   }

  ngOnInit(): void {

    // this.userObject = JSON.parse(sessionStorage.getItem("current_user"))
    // this.first_name = this.userObject['first_name']
    // this.last_name = this.userObject['last_name']
    // this.designation = this.userObject['designation']
    // this.avatar = this.userObject['avatar']

  }

  logout(){
    this.registerService.logout()
    this.alertService.success("Successfully logout", true);
    this.router.navigate(['/login']);
  }

}
