import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }
  readonly baseURL = 'http://127.0.0.1:5000/api/';

  createUser(userObj) {
    return this.http.post(this.baseURL+'register', userObj);
  }

  updateUser(id, userObj){
    return this.http.put(this.baseURL+'update-user/'+id, userObj);
  }

  getAllUsers() {
    return this.http.get(this.baseURL+'view-all-users');
  }
  getUserById(id) {
    return this.http.get(this.baseURL+'find-user-by-id/'+id);
  }
  deleteUserById(id){
    return this.http.delete(this.baseURL+'delete-user-by-id/'+id);
  }

} 
