import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ModelService {

  constructor(private http: HttpClient) { }
  readonly baseURL = 'http://127.0.0.1:5000/api/'; 
  
  createModel(modelObj) {
    console.log(modelObj);
    return this.http.post(this.baseURL+'create-model/', modelObj);
  }

  getAllModels(){
    return this.http.get(this.baseURL+'get-all-models/')
  }

  deleteModelById(id,filename){
    console.log(this.baseURL+'delete-model-by-id/'+ id + '/' + filename);
    
    return this.http.delete(this.baseURL+'delete-model-by-id/'+ id + '/' + filename);
  }

  getModelById(id){
    return this.http.get(this.baseURL+'find-model-by-id/'+id)
  }

  updateModel(id, modelObj){
    return this.http.put(this.baseURL+'update-model/'+id, modelObj);
  }


}


