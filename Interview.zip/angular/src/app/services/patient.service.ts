import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private http: HttpClient) { }
  readonly baseURL = 'http://127.0.0.1:5000/api/';

  createPatient(patientObj) {
    return this.http.post(this.baseURL+'create-patient', patientObj);
  }

  updatePatient(id, patientObj){
    return this.http.put(this.baseURL+'update-patient/'+id, patientObj);
  }

  getAllPatients() {
    return this.http.get(this.baseURL+'view-all-patients');
  }

  getPatientById(id) {
    return this.http.get(this.baseURL+'find-patient-by-id/'+id);
  }

  // get_graph(){
  //   return this.http.get(this.baseURL+'get-graph');
  // }

  get_all_ecg_by_patient_id(id){

    return this.http.get(this.baseURL+'get-all-ecg-by-patient-id/'+id)
  }

  // get_ecg_by_ecg_id(id){
  //   return this.http.get(this.baseURL+'get-ecg-by-ecg-id/'+id)
  // }

  uploadFile(file:File,id){

    let headers = new HttpHeaders({
      'FileName': file.name,
       });
  
    return this.http.post(this.baseURL+'uploader/'+id,file,{
      headers,
      reportProgress : true,
      observe: 'events'

    })
  }

  fileUpload(fileObj){
    console.log(fileObj);
    
    return this.http.post(this.baseURL+'file-uploader', fileObj);
  }

  deletePatientById(id){
    return this.http.delete(this.baseURL+'delete-patient-by-id/'+id);
  }
  
  // update_patient_report(id){
  //   return this.http.get(this.baseURL+'update-patient-report/'+id);
  // }

  view_file(id){
    return this.http.get(this.baseURL+'view-file/'+id);
  }

  getPredictionReportById(id){
    return this.http.get(this.baseURL+'view-prediction-report/'+id);
  }

}
